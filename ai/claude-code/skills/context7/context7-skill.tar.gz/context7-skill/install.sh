#!/bin/bash
#
# Context7 Skill Installation Script
# Quick setup for Claude Code
#

set -e  # Exit on error

echo "=========================================="
echo "Context7 Skill Installation"
echo "=========================================="
echo ""

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Determine Claude skills directory
if [ -d "$HOME/.claude/skills" ]; then
    SKILLS_DIR="$HOME/.claude/skills"
elif [ -d "$HOME/Library/Application Support/Claude/skills" ]; then
    SKILLS_DIR="$HOME/Library/Application Support/Claude/skills"
else
    echo -e "${YELLOW}Creating Claude skills directory...${NC}"
    SKILLS_DIR="$HOME/.claude/skills"
    mkdir -p "$SKILLS_DIR"
fi

echo "Skills directory: $SKILLS_DIR"
echo ""

# Check if Context7 MCP is installed
echo "Checking Context7 MCP installation..."
if claude mcp list 2>/dev/null | grep -q "context7"; then
    echo -e "${GREEN}✓ Context7 MCP is installed${NC}"
else
    echo -e "${RED}✗ Context7 MCP not found${NC}"
    echo ""
    echo "Installing Context7 MCP server..."
    claude mcp add context7 --scope user -- npx -y @upstash/context7-mcp
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Context7 MCP installed successfully${NC}"
    else
        echo -e "${RED}✗ Failed to install Context7 MCP${NC}"
        echo "Please install manually:"
        echo "  claude mcp add context7 --scope user -- npx -y @upstash/context7-mcp"
        exit 1
    fi
fi
echo ""

# Install skill
SKILL_DIR="$SKILLS_DIR/context7"

echo "Installing Context7 skill..."
if [ -d "$SKILL_DIR" ]; then
    echo -e "${YELLOW}⚠ Skill directory already exists: $SKILL_DIR${NC}"
    read -p "Overwrite? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled."
        exit 0
    fi
    rm -rf "$SKILL_DIR"
fi

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Copy skill files
cp -r "$SCRIPT_DIR" "$SKILL_DIR"

# Remove the install script from the installed location
rm -f "$SKILL_DIR/install.sh"

if [ -f "$SKILL_DIR/SKILL.md" ]; then
    echo -e "${GREEN}✓ Skill installed successfully${NC}"
else
    echo -e "${RED}✗ Installation failed${NC}"
    exit 1
fi
echo ""

# Verify installation
echo "Verifying installation..."

# Check SKILL.md frontmatter
if head -5 "$SKILL_DIR/SKILL.md" | grep -q "^name: context7"; then
    echo -e "${GREEN}✓ SKILL.md frontmatter is valid${NC}"
else
    echo -e "${RED}✗ SKILL.md frontmatter may be invalid${NC}"
fi

# Check file permissions
if [ -r "$SKILL_DIR/SKILL.md" ]; then
    echo -e "${GREEN}✓ Skill files are readable${NC}"
else
    echo -e "${RED}✗ Permission issues detected${NC}"
fi

echo ""
echo "=========================================="
echo -e "${GREEN}Installation Complete!${NC}"
echo "=========================================="
echo ""
echo "Next steps:"
echo "  1. Test the skill:"
echo "     claude \"Create a Typer CLI application with config file\""
echo ""
echo "  2. Verify Context7 is invoked:"
echo "     Look for resolve-library-id and get-library-docs calls"
echo ""
echo "  3. Review the documentation:"
echo "     - SUMMARY.md     - Complete overview"
echo "     - QUICK_REFERENCE.md - Fast lookups"
echo "     - EXAMPLES.md    - Before/after scenarios"
echo "     - TESTING.md     - Validation suite"
echo ""
echo "Installation location: $SKILL_DIR"
echo ""

# Optional: Add auto-invocation rule
read -p "Add auto-invocation rule to CLAUDE.md? (y/N) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    CLAUDE_MD="$HOME/.claude/CLAUDE.md"
    
    if [ ! -f "$CLAUDE_MD" ]; then
        touch "$CLAUDE_MD"
        echo "Created $CLAUDE_MD"
    fi
    
    # Check if rule already exists
    if grep -q "Always use Context7" "$CLAUDE_MD"; then
        echo -e "${YELLOW}⚠ Auto-invocation rule already exists in CLAUDE.md${NC}"
    else
        cat >> "$CLAUDE_MD" << 'EOF'

# Context7 Auto-Invocation
Always use Context7 when working with external libraries, frameworks, or APIs.
Automatically invoke Context7 tools to resolve library IDs and fetch documentation
without waiting for explicit requests.

EOF
        echo -e "${GREEN}✓ Auto-invocation rule added to CLAUDE.md${NC}"
    fi
fi

echo ""
echo "Happy coding! 🚀"
